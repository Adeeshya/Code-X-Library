package com.example.libraryappcodex

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.libraryappcodex.databinding.ActivityRequestBookBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class RequestBookActivity : AppCompatActivity() {

    //view binding
    private lateinit var binding: ActivityRequestBookBinding

    //firebase auth
    private lateinit var firebaseAuth: FirebaseAuth

    //progress dialog
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestBookBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //init firebase auth
        firebaseAuth = FirebaseAuth.getInstance()

        //init progress dialog , will show while creating account | Register Use
        progressDialog= ProgressDialog(this)
        progressDialog.setTitle("Please Wait")
        progressDialog.setCanceledOnTouchOutside(false)


        //handle back button
        binding.backBtn.setOnClickListener {
            onBackPressed()//go to previous screen
        }

        //handle click , begin register
        binding.submitBtn.setOnClickListener {
            //steps
            /*
            * 1)Input data
            * 2)validate data
            * 3)save info - firebase realtime databse*/
            validateData()
        }
    }

    private var studentname=""
    private var faculty=""
    private var bookcategory=""
    private var booktitle=""
    private var description=""

    private fun validateData() {
        //1)Input data
        studentname = binding.studentnameEt.text.toString().trim()
        faculty = binding.facultyEt.text.toString().trim()
        bookcategory = binding.bookcategoryEt.text.toString().trim()
        booktitle = binding.booktitleEt.text.toString().trim()
        description = binding.descriptionEt.text.toString().trim()

        // 2)validate data
        if (studentname.isEmpty()){
            Toast.makeText(this,"Enter User Name", Toast.LENGTH_SHORT).show()
        }
        else if(faculty.isEmpty()){
            Toast.makeText(this,"Enter Faculty", Toast.LENGTH_SHORT).show()
        }else if (bookcategory.isEmpty()){
            Toast.makeText(this,"Enter BookCategory", Toast.LENGTH_SHORT).show()
        }
        else if(booktitle.isEmpty()){
            Toast.makeText(this,"Enter BookTitle..", Toast.LENGTH_SHORT).show()
        }else if(description.isEmpty()){
            Toast.makeText(this,"Enter Description", Toast.LENGTH_SHORT).show()
        }
        else{
            submitData()
        }
    }

    private fun submitData() {
        progressDialog.setMessage("Saving your info..")

        //timestamp
        val timestamp= System.currentTimeMillis()

        //get current user uid , since user is registered so we can get it now
        val uid=firebaseAuth.uid

        //setup data to add in db
        val hashMap:HashMap<String,Any?> = HashMap()
        hashMap["uid"]="$uid"
        hashMap["studentname"]="$studentname"
        hashMap["faculty"]="$faculty"
        hashMap["bookcategory"]="$bookcategory"
        hashMap["booktitle"]="$booktitle"
        hashMap["description"]="$description"
        hashMap["timestamp"]="$timestamp"

        //set data into db
        val ref= FirebaseDatabase.getInstance().getReference("RequestedBooks")
        ref.child("$timestamp")
            .setValue(hashMap)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this,"Request Submited ...", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this@RequestBookActivity, AccountUserActivity::class.java))
                finish()
            }
            .addOnFailureListener { e->
                //failed adding data to db
                progressDialog.dismiss()
                Toast.makeText(this,"Failed Submit request due to ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}