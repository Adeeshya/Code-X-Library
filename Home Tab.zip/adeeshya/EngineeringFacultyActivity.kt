package com.example.libraryappcodex

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.libraryappcodex.adapter.AdapterBook1
import com.example.libraryappcodex.databinding.ActivityEngineeringFacultyBinding
import com.example.libraryappcodex.model.ModelBook1
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_engineering_faculty.*

class EngineeringFacultyActivity : AppCompatActivity() {
    //view binding
    private lateinit var binding: ActivityEngineeringFacultyBinding

    lateinit var mDataBase: DatabaseReference
    private lateinit var bookList:ArrayList<ModelBook1>
    private lateinit var mAdapter: AdapterBook1

    //firebase auth
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEngineeringFacultyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //init firebase auth
        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()

        /**initialized*/
        bookList = ArrayList()
        mAdapter = AdapterBook1(this,bookList)
        booksImagesRv.layoutManager = LinearLayoutManager(this)
        booksImagesRv.setHasFixedSize(true)
        booksImagesRv.adapter = mAdapter
        /**getData firebase*/
        getBooksData()


        //handle click home
        binding.homeBtn.setOnClickListener{
            startActivity(Intent(this, DashboardUserActivity::class.java))
        }
        //handle click mybooks
        binding.mybooksBtn.setOnClickListener{
            startActivity(Intent(this, MyBooksActivity::class.java))
        }
        //handle click notifications
        binding.notificationsBtn.setOnClickListener{
            startActivity(Intent(this, NotificationActivity2::class.java))
        }
        //handle click ebooks
        binding.ebooksBtn.setOnClickListener{
            startActivity(Intent(this, EbooksActivity::class.java))
        }
        //handle click account
        binding.accountBtn.setOnClickListener{
            startActivity(Intent(this, AccountUserActivity::class.java))
        }


    }

    private fun getBooksData() {
        mDataBase = FirebaseDatabase.getInstance().getReference("Books")
        mDataBase.orderByChild("faculty").equalTo("Faculty of engineering")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()){
                        for (bookSnapshot in snapshot.children){
                            val book = bookSnapshot.getValue(ModelBook1::class.java)
                            bookList.add(book!!)
                        }
                        booksImagesRv.adapter = mAdapter
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@EngineeringFacultyActivity,
                        error.message, Toast.LENGTH_SHORT).show()
                }

            })
    }

    private fun checkUser() {
        //get current user
        val firebaseUser = firebaseAuth.currentUser
        if(firebaseUser==null){
            //not logged in , go to main screen
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        else{
            //logged in get and show user info
            val email = firebaseUser.email
            //set to textview of toolbar
            binding.usernameTv.text=email
        }
    }
}